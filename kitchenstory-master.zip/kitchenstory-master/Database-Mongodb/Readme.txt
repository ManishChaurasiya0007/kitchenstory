Step 1 - In Mongodb compass create database "kitchenstory".
Step 2 - Inside db kitchenstory create Collections- AdminCred, Orders, Products.
Step 3 - In respective collections import the .csv file.